<?php
session_start();
if (!isset($_SESSION['user_logged_in'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pemesanan - TAHULEK</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .order-container {
            max-width: 500px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
        .order-container h2 {
            margin-bottom: 20px;
            color: #ff7a00;
            text-align: center;
        }
        .input-group {
            margin-bottom: 15px;
        }
        .input-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
        }
        .input-group input, .input-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
        }
        .btn-submit {
            width: 100%;
            padding: 12px;
            background-color: #ff7a00;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-submit:hover {
            background-color: #e06b00;
        }
    </style>
</head>
<body>

    <div class="order-container">
        <h2><i class="fa-solid fa-cart-shopping"></i> Form Pemesanan Produk</h2>
        
        <form action="proses_pemesanan.php" method="POST">
            <div class="input-group">
                <label for="nama_pemesan">Nama Pemesan</label>
                <input type="text" id="nama_pemesan" name="nama_pemesan" placeholder="Masukkan nama Anda" required>
            </div>

            <div class="input-group">
                <label for="nama_produk">Nama Produk</label>
                <select id="nama_produk" name="nama_produk" required>
                    <option value="">-- Pilih Menu Tahulek --</option>
                    <option value="Tahu Walek Original">Tahu Walek Original</option>
                    <option value="Tahu Walek Pedas Mercon">Tahu Walek Pedas</option>
                    <option value="Paket Mix Tahulek">Paket Mix Tahulek</option>
                </select>
            </div>

            <div class="input-group">
                <label for="harga">Harga Satuan (Rp)</label>
                <input type="number" id="harga" name="harga" placeholder="Contoh: 15000" min="1" required>
            </div>

            <div class="input-group">
                <label for="jumlah">Jumlah Beli</label>
                <input type="number" id="jumlah" name="jumlah" placeholder="Contoh: 2" min="1" required>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-calculator"></i> Hitung & Pesan
            </button>
        </form>
    </div>

</body>
</html>