<?php
session_start();
if (!isset($_SESSION['user_logged_in'])) {
    header("Location: login.php");
    exit();
}

$error_message = "";
$sukses = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_pemesan = trim($_POST['nama_pemesan']);
    $nama_produk  = trim($_POST['nama_produk']);
    $harga        = trim($_POST['harga']);
    $jumlah       = trim($_POST['jumlah']);

    if (empty($nama_pemesan) || empty($nama_produk) || $harga === "" || $jumlah === "") {
        $error_message = "Semua field wajib diisi secara lengkap!";
    } 
    elseif (!is_numeric($harga) || !is_numeric($jumlah) || $harga <= 0 || $jumlah <= 0) {
        $error_message = "Harga dan Jumlah beli tidak boleh bernilai nol atau negatif!";
    } else {
        $sukses = true;
        
        $harga = (float) $harga;
        $jumlah = (int) $jumlah;

        function hitungTotal($harga, $jumlah) {
            $subtotal = $harga * $jumlah;
            $diskon = 0;
            $persen_diskon = 0;

            if ($subtotal > 100000) {
                $persen_diskon = 10;
                $diskon = $subtotal * 0.10;
            }

            $total_bayar = $subtotal - $diskon;

            return [
                'subtotal' => $subtotal,
                'persen_diskon' => $persen_diskon,
                'diskon' => $diskon,
                'total_bayar' => $total_bayar
            ];
        }

        $hasil_hitung = hitungTotal($harga, $jumlah);
    }
} else {
    header("Location: form_pemesanan.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pemesanan - TAHULEK</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .result-container {
            max-width: 600px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            text-align: center;
        }
        .alert-error {
            background-color: #ffe6e6;
            color: #cc0000;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #ffcccc;
        }
        table.result-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            text-align: left;
        }
        table.result-table th, table.result-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        table.result-table th {
            background-color: #fff8f0;
            color: #ff7a00;
            width: 40%;
        }
        .btn-back {
            display: inline-block;
            margin-top: 25px;
            padding: 10px 20px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 500;
            transition: background 0.2s;
        }
        .btn-back:hover {
            background-color: #555;
        }
    </style>
</head>
<body>

    <div class="result-container">
        <?php if (!$sukses): ?>
            <h2><i class="fa-solid fa-triangle-exclamation" style="color: #cc0000;"></i> Validasi Gagal</h2>
            <div class="alert-error">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
            <a href="form_pemesanan.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Form</a>

        <?php else: ?>
            <h2><i class="fa-solid fa-circle-check" style="color: #28a745;"></i> Rincian Pesanan Berhasil</h2>
            <p>Terima kasih, pesanan Anda telah diproses.</p>

            <table class="result-table">
                <tr>
                    <th>Nama Pemesan</th>
                    <td><?php echo htmlspecialchars($nama_pemesan); ?></td>
                </tr>
                <tr>
                    <th>Nama Produk</th>
                    <td><?php echo htmlspecialchars($nama_produk); ?></td>
                </tr>
                <tr>
                    <th>Harga Satuan</th>
                    <td>Rp <?php echo number_format($harga, 0, ',', '.'); ?></td>
                </tr>
                <tr>
                    <th>Jumlah Beli</th>
                    <td><?php echo $jumlah; ?> pcs</td>
                </tr>
                <tr>
                    <th>Subtotal (Sebelum Diskon)</th>
                    <td>Rp <?php echo number_format($hasil_hitung['subtotal'], 0, ',', '.'); ?></td>
                </tr>
                <tr>
                    <th>Diskon (<?php echo $hasil_hitung['persen_diskon']; ?>%)</th>
                    <td>Rp <?php echo number_format($hasil_hitung['diskon'], 0, ',', '.'); ?></td>
                </tr>
                <tr style="font-weight: bold; background-color: #fff8f0;">
                    <th>Total Bayar</th>
                    <td style="color: #ff7a00;">Rp <?php echo number_format($hasil_hitung['total_bayar'], 0, ',', '.'); ?></td>
                </tr>
            </table>

            <a href="form_pemesanan.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Pesan Lagi</a>
        <?php endif; ?>
    </div>

</body>
</html>