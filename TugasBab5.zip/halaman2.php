<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Detail Produk - TAHULEK</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <header class="detail-header">
    <div class="container nav-detail">
      <a href="index.php" class="btn btn-back">
        <i class="fa-solid fa-arrow-left"></i> Kembali
      </a>
      
      <a href="index.php" class="logo-container">
        <div class="logo-icon">
           <img src="image/tahulek.png" alt="" width="50px">
        </div>
        <span class="brand-name">Tahu<span>lek</span></span>
      </a>
    </div>
  </header>

  <main class="container detail-container">

    <section class="detail-hero">
      <div class="detail-hero-img">
        <img src="image/tahu.jpg" alt="Foto Produk Tahulek">
      </div>
      <div class="detail-hero-info">
        <span class="badge-tag">Kuliner Khas Banyuwangi</span>
        <h1>TAHULEK</h1>
        <h2>Tahu Walik Gurih & Renyah</h2>
        <p class="description-text">
          <strong>TAHULEK</strong> adalah singkatan dari <em>tahu walek</em> (tahu walik). Tahu walik biasa dijadikan sebagai kudapan atau camilan gorengan yang pas dinikmati kapan saja.
        </p>
        <p class="description-text">
          Bagian kulit tahu dibalik ke luar sehingga sisi putih daging tahu berada di bagian luar, lalu diisi adonan daging, ayam, atau aci (tapioka). Makanan ini memiliki tekstur yang sangat renyah di luar dan gurih padat di dalam.
        </p>
      </div>
    </section>

    <section class="variant-section">
      <div class="section-title">
        <h2>Varian Rasa Tahulek</h2>
        <p>Pilih atau kombinasikan varian favoritmu!</p>
      </div>

      <div class="variant-grid">
        <div class="variant-card">
          <div class="variant-img">
            <img src="image/original.jpg" alt="Tahulek Original">
          </div>
          <div class="variant-info">
            <h3>Varian Original</h3>
            <p>Rasa gurih alami dengan isian adonan pilihan dan cocolan kecap pedas gurih.</p>
            <a href="halaman3.php" class="btn btn-outline">
              <i class="fa-solid fa-book-open"></i> Resep Original
            </a>
          </div>
        </div>

        <div class="variant-card">
          <div class="variant-img">
            <img src="image/pedas.jpg" alt="Tahulek Pedas">
          </div>
          <div class="variant-info">
            <h3>Varian Pedas</h3>
            <p>Sentuhan bumbu pedas cabai rawit segar yang meresap hingga ke dalam adonan.</p>
            <a href="halaman4.php" class="btn btn-primary">
              <i class="fa-solid fa-fire"></i> Resep Pedas
            </a>
          </div>
        </div>

        <div class="variant-card">
          <div class="variant-img">
            <img src="image/tahu.jpg" alt="Tahulek Mix">
          </div>
          <div class="variant-info">
            <h3>Varian Mix</h3>
            <p>Pilihan untuk yang ingin menyicipi original dan pedas tanpa harus membeli keduanya.</p>
          </div>
        </div>

      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2026 Tahulek. All Rights Reserved. | Serly Aulia 2518015</p>
  </footer>

</body>
</html>