<?php

session_start();

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <div class="container session-content">
        <div class="user-greeting">
            <i class="fa-solid fa-user-circle"></i>
            <span>Halo, <strong><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></strong></span>
        </div>
        <a href="logout.php" class="btn-logout">
            <i class="fa-solid fa-right-from-bracket"></i> Keluar
        </a>
    </div>
    <meta charset="UTF-8">
    <title>Beranda - TAHULEK</title>
</head>
<body>
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TAHULEK - Emang Boleh Seenak Ini?</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  
  <style>
    .cart-badge {
      background-color: var(--primary-color, #ffb72b);
      color: white;
      font-size: 12px;
      padding: 2px 8px;
      border-radius: 20px;
      margin-left: 4px;
    }
    .theme-toggle-btn {
      background: transparent;
      border: 1px solid var(--primary-color, #ffb72b);
      color: var(--dark-text, #222);
      padding: 8px 12px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
      transition: all 0.3s;
    }
    .theme-toggle-btn:hover {
      background-color: var(--primary-color, #ffb72b);
      color: white;
    }
    .search-filter-box {
      margin-bottom: 25px;
      text-align: center;
    }
    .search-filter-box input {
      padding: 10px 16px;
      width: 100%;
      max-width: 400px;
      border-radius: 10px;
      border: 1px solid #ccc;
      font-size: 14px;
      outline: none;
    }

    /* Styling Tambahan Pop-up Box / Modal */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      display: none;
      justify-content: center;
      align-items: center;
      z-index: 1000;
      backdrop-filter: blur(3px);
    }
    .modal-card {
      background: #fff;
      padding: 25px;
      border-radius: 16px;
      max-width: 450px;
      width: 90%;
      text-align: center;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
      position: relative;
      animation: popupAnim 0.3s ease;
    }
    @keyframes popupAnim {
      from { transform: scale(0.8); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
    .modal-card h3 {
      margin-bottom: 10px;
      color: #222;
    }
    .modal-card p {
      color: #666;
      font-size: 14px;
      margin-bottom: 20px;
    }
    .btn-close-modal {
      position: absolute;
      top: 12px;
      right: 15px;
      font-size: 20px;
      cursor: pointer;
      color: #888;
    }
    .btn-modal-action {
      background-color: #ffb72b;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
    }

    /* Style Spinner Async Loading */
    .loading-spinner {
      display: none;
      margin: 15px auto;
      border: 4px solid #f3f3f3;
      border-top: 4px solid #ffb72b;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  
  <div id="toast-container"></div>

  <!-- POP-UP BOX 1: Modal Promo Sambutan (Memanfaatkan Window Event) -->
  <div id="promo-modal" class="modal-overlay">
    <div class="modal-card">
      <span class="btn-close-modal" id="close-promo-btn">&times;</span>
      <i class="fa-solid fa-gift" style="font-size: 40px; color: #ffb72b; margin-bottom: 10px;"></i>
      <h3>Promo Spesial Hari Ini!</h3>
      <p>Dapatkan diskon 20% untuk pembelian varian <b>Tahulek Mix</b> dengan menyebarkan resep favoritmu!</p>
      <button class="btn-modal-action" id="close-promo-action">Klaim Promo</button>
    </div>
  </div>

  <!-- POP-UP BOX 2: Modal Detail Produk -->
  <div id="product-modal" class="modal-overlay">
    <div class="modal-card">
      <span class="btn-close-modal" id="close-detail-btn">&times;</span>
      <h3 id="modal-product-title">Detail Produk</h3>
      <div id="modal-spinner" class="loading-spinner"></div>
      <div id="modal-product-body">
        <p id="modal-product-desc">Memuat data produk...</p>
        <p><b>Kalori:</b> <span id="modal-product-calories">-</span> kcal</p>
      </div>
      <button class="btn-modal-action" id="modal-buy-btn">Beli Sekarang</button>
    </div>
  </div>

  <header>
    <div class="container">
      <nav>
        <a href="index.php" class="logo-container">
          <div class="logo-icon">
             <img src="image/tahulek.png" alt="Logo" width="50px">
          </div>
          <span class="brand-name">Tahu<span>lek</span></span>
        </a>
        
        <input type="checkbox" id="menu-toggle" style="display: none;">
        <label for="menu-toggle" class="menu-btn">
          <i class="fa-solid fa-bars"></i>
        </label>
        
        <ul class="nav-links">
          <li><a href="index.php" class="active">Beranda</a></li>
          <li><a href="#kategori">Kategori</a></li>
          <li><a href="#menu">Pesan Online</a></li>
          <li>
            <a href="#" id="cart-link">
              <i class="fa-solid fa-cart-shopping"></i> Keranjang 
              <span id="cart-count" class="cart-badge">0</span>
            </a>
          </li>
          <li>
            <button id="btn-theme-toggle" class="theme-toggle-btn">
              <i class="fa-solid fa-moon"></i>
            </button>
          </li>
          <li><a href="login.php" class="btn btn-outline">Masuk</a></li>
          <li><a href="register.php" class="btn btn-primary">Daftar</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main class="container">
    <section class="jumbotron">
      <div class="jumbotron-text">
        <h1>TAHULEK</h1>
        <h2>Emang boleh seenak ini?</h2>
        <p>Nikmati kerenyahan tahu walik gurih khas resep istimewa dengan cocolan sambal ulek pedas nagih yang melimpah!</p>
        <a href="#menu" class="btn btn-light">Pesan Sekarang <i class="fa-solid fa-arrow-right"></i></a>
      </div>
      <div class="jumbotron-img">
        <img src="image/tahu.jpg" alt="Tahu Walik">
      </div>
    </section>

    <section id="kategori" class="cards-categories">
      <div class="section-title">
        <h2>Menu Favorit Tahulek</h2>
        <p>Pilih varian rasa sesuai dengan selera pedasmu</p>
      </div>

      <div class="search-filter-box">
        <input type="text" id="search-input" placeholder="Cari varian Tahulek (Ketik nama menu)...">
      </div>

      <div class="card-categories" id="menu">
        <div class="card" data-title="Tahulek Original">
          <div class="card-image">
            <img src="image/original.jpg" alt="Tahulek Original">
          </div>
          <div class="card-content">
            <h5 class="product-title">Tahulek Original</h5>
            <p class="description">Tahu walik renyah di luar, lembut di dalam lengkap dengan sambal ulek kecap pedas gurih.</p>
            <div class="card-footer">
              <p class="price">Rp 5.000</p>
              <button class="btn_belanja btn-buy"><i class="fa-solid fa-cart-shopping"></i> Beli</button>
            </div>
          </div>
        </div>

        <div class="card" data-title="Tahulek Pedas">
          <div class="card-image">
            <img src="image/pedas.jpg" alt="Tahulek Pedas">
          </div>
          <div class="card-content">
            <h5 class="product-title">Tahulek Pedas</h5>
            <p class="description">Sensasi cabai rawit merah ulek segar melimpah bagi kamu pencinta tantangan pedas ekstrem.</p>
            <div class="card-footer">
              <p class="price">Rp 5.000</p>
              <button class="btn_belanja btn-buy"><i class="fa-solid fa-cart-shopping"></i> Beli</button>
            </div>
          </div>
        </div>

        <div class="card" data-title="Tahulek Mix">
          <div class="card-image">
            <img src="image/tahu.jpg" alt="Tahulek Mix">
          </div>
          <div class="card-content">
             <h5 class="product-title">Tahulek Mix</h5>
             <p class="description">Kombinasi Tahulek original dan Tahulek pedas agar bisa mencicipi keduanya langsung.</p>
             <div class="card-footer">
              <p class="price">Rp 5.000</p>
              <button class="btn_belanja btn-buy"><i class="fa-solid fa-cart-shopping"></i> Beli</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2026 Tahulek. All Rights Reserved. | Serly Aulia 2518015</p>
  </footer>

  <script>

    // 1. TOAST NOTIFICATION (Pop-up Pesan Kecil)
    function showToast(message) {
      const toastContainer = document.getElementById('toast-container');
      const toast = document.createElement('div');
      toast.className = 'toast';
      toast.innerHTML = `<i class="fa-solid fa-circle-check"></i> <span>${message}</span>`;
      
      toastContainer.appendChild(toast);
      
      setTimeout(() => { toast.classList.add('show'); }, 100);
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => { toast.remove(); }, 400);
      }, 3000);
    }
    // 2. WEB STORAGE (localStorage)
    let totalItems = parseInt(localStorage.getItem('cart_count')) || 0;
    const cartCountElement = document.getElementById('cart-count');
    cartCountElement.innerText = totalItems;

    // Ambil status tema dari localStorage
    if (localStorage.getItem('theme') === 'dark') {
      document.body.classList.add('dark-theme');
      document.body.style.backgroundColor = '#1e1e1e';
      document.body.style.color = '#ffffff';
      document.getElementById('btn-theme-toggle').innerHTML = '<i class="fa-solid fa-sun"></i>';
    }

    // EVENT 1: Window Event ('load')
    window.addEventListener('load', () => {
      const promoModal = document.getElementById('promo-modal');
      promoModal.style.display = 'flex';
    });

    // EVENT 2: Keyboard Event ('keyup')
    const searchInput = document.getElementById('search-input');
    const cards = document.querySelectorAll('.card-categories .card');
    
    searchInput.addEventListener('keyup', (e) => {
      const filterText = e.target.value.toLowerCase();
      cards.forEach(card => {
        const title = card.getAttribute('data-title').toLowerCase();
        if (title.includes(filterText)) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });

    // EVENT 3: Mouse Event ('click' & 'dblclick')
    const buyButtons = document.querySelectorAll('.btn-buy');
    buyButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const cardTitle = e.target.closest('.card').querySelector('.product-title').innerText;
        
        totalItems++;
        cartCountElement.innerText = totalItems;
        localStorage.setItem('cart_count', totalItems); // Simpan ke Web Storage
        
        showToast(`${cardTitle} ditambahkan ke keranjang!`);
      });
    });

    // Double Click Kartu Produk untuk mengambil detail dengan Fetch
    cards.forEach(card => {
      card.addEventListener('dblclick', () => {
        const title = card.getAttribute('data-title');
        ambilDataProduk(title); // Panggil fungsi Fetch
      });
    });

    // Toggle Dark Mode
    const themeBtn = document.getElementById('btn-theme-toggle');
    themeBtn.addEventListener('click', () => {
      document.body.classList.toggle('dark-theme');
      const isDark = document.body.classList.contains('dark-theme');
      
      if (isDark) {
        document.body.style.backgroundColor = '#1e1e1e';
        document.body.style.color = '#ffffff';
        themeBtn.innerHTML = '<i class="fa-solid fa-sun"></i>';
        localStorage.setItem('theme', 'dark');
        showToast('Mode Gelap diaktifkan');
      } else {
        document.body.style.backgroundColor = '';
        document.body.style.color = '';
        themeBtn.innerHTML = '<i class="fa-solid fa-moon"></i>';
        localStorage.setItem('theme', 'light');
        showToast('Mode Terang diaktifkan');
      }
    });

    // ----------------------------------------------------
    // 4. DUA POP-UP BOX
    document.getElementById('close-promo-btn').onclick = () => {
      document.getElementById('promo-modal').style.display = 'none';
    };
    document.getElementById('close-promo-action').onclick = () => {
      document.getElementById('promo-modal').style.display = 'none';
      showToast('Promo berhasil diklaim!');
    };

    // Penutup Modal Detail Produk (Pop-up 2)
    document.getElementById('close-detail-btn').onclick = () => {
      document.getElementById('product-modal').style.display = 'none';
    };

    // ----------------------------------------------------
    // FETCH
    function ambilDataProduk(namaProduk) {
      const modal = document.getElementById('product-modal');
      const titleElem = document.getElementById('modal-product-title');
      const descElem = document.getElementById('modal-product-desc');

      titleElem.innerText = namaProduk;
      descElem.innerText = "Mengambil data dari server...";
      modal.style.display = 'flex';

      fetch('https://jsonplaceholder.typicode.com/posts/1')
        .then(response => response.json())
        .then(data => {
          console.log(data);
          descElem.innerText = `Deskripsi Spesial ${namaProduk}: Tahu walik renyah di luar, kenyal gurih di dalam dengan bumbu kecap khas Banyuwangi.`;
        })
        .catch(error => {
          console.error('Terjadi kesalahan:', error);
          descElem.innerText = "Gagal mengambil data produk dari server.";
        });
    }
  </script>
</body>
</html>