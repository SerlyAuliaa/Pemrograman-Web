<?php
session_start();

$_SESSION = array();
session_destroy();

if (isset($_COOKIE['user_cookie'])) {
    setcookie("user_cookie", "", time() - 3600, "/");
}

header("Location: login.php");
exit();
?>