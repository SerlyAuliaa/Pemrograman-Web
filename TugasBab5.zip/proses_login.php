<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<?php
session_start();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    
    $remember = isset($_POST['remember']) ? true : false;

    $dummy_username = "serly";
    $dummy_password = "12345";

    if ($username === $dummy_username && $password === $dummy_password) {
        
        // 1. MEMBUAT SESSION
        $_SESSION['user_logged_in'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['nama_lengkap'] = "Serly Aulia";

        if ($remember) {
            // Cookie berlaku selama 7 hari (7 * 24 * 60 * 60 detik)
            setcookie("user_cookie", $username, time() + (86400 * 7), "/");
        }

        header("Location: index.php");
        exit();

    } else {
        echo "<script>
                alert('Username atau Password salah!');
                window.location.href = 'login.php';
              </script>";
    }
} else {
    header("Location: login.php");
    exit();
}
?>, initial-scale=1.0">
    <title>Document</title>
</body>
</html>