<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar Akun - TAHULEK</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
    <div class="container">
      <nav>
        <a href="index.php" class="logo-container">
          <div class="logo-icon">
           <img src="image/tahulek.png" alt="" width="50px">
          </div>
          <span class="brand-name">Tahu<span>lek</span></span>
        </a>

        <ul class="nav-links">
          <li><a href="index.php">Beranda</a></li>
          <li><a href="login.php" class="btn btn-outline">Masuk</a></li>
        </ul>
      </nav>
    </div>
  </header>

<main class="auth-wrapper">
    <div class="auth-card">
      <div class="auth-header">
        <h2>Buat Akun Baru</h2>
        <p>Bergabunglah & nikmati kemudahan pesan Tahulek!</p>
      </div>

      <form action="login.php" method="GET">
        <div class="input-group">
          <label for="fullname">Nama Lengkap</label>
          <div class="input-wrapper">
            <i class="fa-regular fa-id-card input-icon"></i>
            <input type="text" id="fullname" name="fullname" class="input" placeholder="Masukkan nama lengkap" required>
          </div>
        </div>

        <div class="input-group">
          <label for="reg-email">Alamat Email / No. WhatsApp</label>
          <div class="input-wrapper">
            <i class="fa-regular fa-envelope input-icon"></i>
            <input type="email" id="reg-email" name="email" class="input" placeholder="contoh@email.com" required>
          </div>
        </div>

        <div class="input-group">
          <label for="reg-password">Password</label>
          <div class="input-wrapper">
            <i class="fa-solid fa-lock input-icon"></i>
            <input type="checkbox" id="toggle-pwd-reg1" class="show-pwd-checkbox">
            <input type="password" id="reg-password" name="password" class="input" placeholder="Minimal 6 karakter" required minlength="6">
            <label for="toggle-pwd-reg1" class="show-pwd-label">
              <i class="fa-regular fa-eye-slash pwd-slash"></i>
              <i class="fa-regular fa-eye pwd-text"></i>
            </label>
          </div>
        </div>

        <div class="input-group">
          <label for="reg-confirm-password">Konfirmasi Password</label>
          <div class="input-wrapper">
            <i class="fa-solid fa-shield-halved input-icon"></i>
            <input type="checkbox" id="toggle-pwd-reg2" class="show-pwd-checkbox">
            <input type="password" id="reg-confirm-password" name="confirm_password" class="input" placeholder="Ulangi password" required minlength="6">
            <label for="toggle-pwd-reg2" class="show-pwd-label">
              <i class="fa-regular fa-eye-slash pwd-slash"></i>
              <i class="fa-regular fa-eye pwd-text"></i>
            </label>
          </div>
        </div>

        <div class="form-options">
          <label class="remember-me">
            <input type="checkbox" name="terms" required> Saya menyetujui <a href="#" class="auth-link">Syarat & Ketentuan</a>
          </label>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px;">
          DAFTAR SEKARANG <i class="fa-solid fa-user-plus"></i>
        </button>

        <div class="divider">
          <span>atau</span>
        </div>

        <div class="auth-footer">
          Sudah punya akun? <a href="login.php" class="auth-link">Masuk Di Sini</a>
        </div>
      </form>
    </div>
  </main>

<footer>
    <p>&copy; 2026 Tahulek. All Rights Reserved. | Serly Aulia 2518015</p>
  </footer>

</body>
</html>